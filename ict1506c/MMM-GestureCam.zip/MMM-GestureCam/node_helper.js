var NodeHelper = require("node_helper");

module.exports = NodeHelper.create({
    start: function() {
        console.log("Starting node_helper for MMM-GestureCam");
    }
});
